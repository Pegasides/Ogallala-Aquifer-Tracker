# My Aquifer — Alliance Pilot v2

Version 2 changes the product principle from **“link to the data”** to **“bring the useful data onto the dashboard.”** Official pages remain secondary verification sources.

## Files to copy into the existing GitHub repository

- `my-aquifer.html`
- `wildflower-before.jpg`
- `wildflower-garden-wide.jpg`
- `wildflower-garden-1.jpg`
- `wildflower-garden-2.jpg`
- `wildflower-butterfly.jpg`
- `wildflower-bee.jpg`
- `wildflower-garden-video.mp4`

Keep these asset files in the same directory as `my-aquifer.html` unless the HTML paths are changed.

## V2 data snapshot

- USGS/UNL public monitoring well 26N 49W 6CC: latest 213.44 ft below land surface, measured 2025-03-20; 1,568 measurements over 55.6 years.
- PREMA: status snapshot 2026-08-10; all displayed groups A–J appeared Normal when checked. Control status changes and should eventually be refreshed dynamically. PREMA public materials do not publish a numeric month-by-month peak-kW series, so V2 does not invent one.
- City of Alliance: 2025 Annual Water Quality Report; actual result table summarized inside the page.
- UNWNRD: 2024 Rules & Regulations, including 2025–2029 allocation table for subareas 4 & 6.
- Water-Wise Living: six user-supplied photos including the bare-ground before image, plus the 28.95-second supplied video.

## Suggested GitHub commit message

`Version 2 — bring data onto dashboard + Water-Wise before/after`
